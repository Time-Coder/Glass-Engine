tree-sitter-glsl
==================

This is a extension of [tree-sitter-c](https://github.com/tree-sitter/tree-sitter-c) to support
the syntax of GLSL (https://www.khronos.org/opengl/wiki/Core_Language_(GLSL)).
